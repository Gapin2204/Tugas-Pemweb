// JavaScript untuk mengubah informasi perkenalan diri
document.getElementById('ubah-informasi').addEventListener('click', function() {
    // Ganti informasi dengan prompt (dari user input)
    var nama = prompt("Masukkan Nama Lengkap:", "Nama Lengkap");
    if (nama != null) {
        document.getElementById('nama-lengkap').textContent = nama;
    }

    var jurusan = prompt("Masukkan Jurusan:", "Jurusan");
    if (jurusan != null) {
        document.getElementById('jurusan').textContent = jurusan;
    }

    var universitas = prompt("Masukkan Nama Universitas:", "Nama Universitas");
    if (universitas != null) {
        document.getElementById('universitas').textContent = universitas;
    }

    var semester = prompt("Masukkan Semester:", "Semester");
    if (semester != null) {
        document.getElementById('semester').textContent = semester;
    }

    var minat = prompt("Masukkan Bidang Minat:", "Bidang yang diminati");
    if (minat != null) {
        document.getElementById('minat').textContent = minat;
        document.getElementById('bidang-minat').textContent = minat;
    }

    var email = prompt("Masukkan Email:", "Alamat Email");
    if (email != null) {
        document.getElementById('email').textContent = email;
    }

    var telepon = prompt("Masukkan Nomor Telepon:", "Nomor Telepon");
    if (telepon != null) {
        document.getElementById('telepon').textContent = telepon;
    }

    var linkedin = prompt("Masukkan URL LinkedIn:", "URL LinkedIn");
    if (linkedin != null) {
        document.getElementById('linkedin').textContent = linkedin;
        document.getElementById('linkedin').setAttribute('href', linkedin);
    }
});
