// Mendapatkan elemen video
const video = document.getElementById('perkenalan-video');

// Mendapatkan elemen tombol
const playButton = document.getElementById('play-button');
const pauseButton = document.getElementById('pause-button');

// Fungsi untuk memutar video
playButton.addEventListener('click', function() {
    video.play();
    playButton.disabled = true; // Menonaktifkan tombol "Putar" setelah video diputar
    pauseButton.disabled = false; // Mengaktifkan tombol "Jeda"
});

// Fungsi untuk menjeda video
pauseButton.addEventListener('click', function() {
    video.pause();
    playButton.disabled = false; // Mengaktifkan tombol "Putar" setelah video dijeda
    pauseButton.disabled = true; // Menonaktifkan tombol "Jeda"
});

// Pada awal, tombol "Jeda" tidak aktif karena video belum diputar
pauseButton.disabled = true;
